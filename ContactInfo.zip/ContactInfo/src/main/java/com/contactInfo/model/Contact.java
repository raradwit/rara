package com.contactInfo.model;

import com.mongodb.DBObject;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * Created by spandey on 4/13/15.
 */

@Document(collection = "contactInfo")
public class Contact {

    @Id
    private String id;
    String country;
    String zipCode;
    String city;
    String state;
    List<String> email;
    List<String> telephone;

    public Contact(){}

    public Contact(String country, String zipCode, String city, String state, List<String> email, List<String> telephone) {
        this.country = country;
        this.zipCode = zipCode;
        this.city = city;
        this.state = state;
        this.email = email;
        this.telephone = telephone;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public List<String> getEmail() {
        return email;
    }

    public void setEmail(List<String> email) {
        this.email = email;
    }

    public List<String> getTelephone() {
        return telephone;
    }

    public void setTelephone(List<String> telephone) {
        this.telephone = telephone;
    }


    @Override
    public String toString() {
        return this.getClass().getCanonicalName()+":"+ this.id;
    }
}
