package com.contactInfo.services;

import com.contactInfo.model.Contact;
import com.mongodb.BasicDBObject;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * Created by spandey on 4/14/15.
 */

public class ContactService {

    MongoOperations mongoOperation;

    public void connection(){
        // For Annotation
        /*ApplicationContext ctx =
                new AnnotationConfigApplicationContext(MConnection.class);
        mongoOperation = (MongoOperations) ctx.getBean("mongoTemplate");*/

        ApplicationContext ctx = new GenericXmlApplicationContext("SpringConfig.xml");
        mongoOperation = (MongoOperations)ctx.getBean("mongoTemplate");
    }


    public String saveContact(HttpServletRequest request){
        this.connection();

        String id = request.getParameter("id");
        Contact contact = null;
        String country = request.getParameter("country");
        String state = request.getParameter("state");
        String city = request.getParameter("city");
        String zipCode = request.getParameter("zipCode");
        ArrayList<String> emailList = new ArrayList();
        emailList.add(request.getParameter("email1"));
        emailList.add(request.getParameter("email2"));

        ArrayList<String> phone = new ArrayList();
        phone.add(request.getParameter("phone1"));
        phone.add(request.getParameter("phone2"));


        if(id!=null){
            BasicQuery query1 = new BasicQuery("{ id : '"+id+"' }");
            contact = mongoOperation.findOne(query1,Contact.class);
            contact.setCountry(country);
            contact.setCity(city);
            contact.setState(state);
            contact.setZipCode(zipCode);
            contact.setEmail(emailList);
            contact.setTelephone(phone);
        }else{
            contact = new Contact(country,zipCode,city,state,emailList,phone);
        }



        mongoOperation.save(contact);

        String contactJson = stringifyJsonFromContacts(contact);
        return contactJson;
    }

    public List<Contact> getContactList(){
        this.connection();
        List<Contact> contacts = mongoOperation.findAll(Contact.class);
        System.out.println("the contacts ===>>>"+contacts);

        return contacts;
    }

    public String getContactList1(){
        this.connection();

        List<Contact> contacts = mongoOperation.findAll(Contact.class);
        System.out.println(contacts);

        String contactJson = stringifyJsonFromContacts(contacts);

        System.out.println("the contacts ===>>>"+contactJson);
        return contactJson;
    }

    public String deleteContact(HttpServletRequest request){
        this.connection();
        String id = request.getParameter("id");
        BasicQuery query1 = new BasicQuery("{ id : '"+id+"' }");
        Contact contact = mongoOperation.findAndRemove(query1, Contact.class);
        String contactJson = stringifyJsonFromContacts(contact);
        return contactJson;
    }

    public String searchContact(HttpServletRequest request){
        this.connection();

        String country = request.getParameter("countrySearch");
        String state = request.getParameter("stateSearch");
        String city = request.getParameter("citySearch");
        String zipCode = request.getParameter("zipCodeSearch");
        String email = request.getParameter("emailSearch");
        String phone = request.getParameter("phoneSearch");

        //DBCollection collection = mongoOperation.getCollection("contactInfo");


        BasicDBObject condition = new BasicDBObject();
        List<BasicDBObject> andCond = new ArrayList<BasicDBObject>();

        if(country != null && country.trim() !="")
            andCond.add(new BasicDBObject("country", country));

        if(state != null && state.trim() !="")
            andCond.add(new BasicDBObject("state", state));
        if(city != null && city.trim() !="")
            andCond.add(new BasicDBObject("city", city));
        if(zipCode != null && zipCode.trim() !="")
            andCond.add(new BasicDBObject("zipCode", zipCode));
        if(email != null && email.trim() !="")
            andCond.add(new BasicDBObject("email", email));
        if(phone != null && phone.trim() !="")
            andCond.add(new BasicDBObject("telephone", phone));

        if(andCond.size()>0)
            condition.put("$and", andCond);

        System.out.println(condition.toString());

        BasicQuery query1 = new BasicQuery(condition.toString());
        List<Contact> contacts = mongoOperation.find(query1, Contact.class);
        System.out.println(contacts);


        //System.out.println(collection.find(condition));

        String contactJson = stringifyJsonFromContacts(contacts);

        /*DBCursor cursor = collection.find(condition);
        while (cursor.hasNext()) {
            System.out.println(cursor.next());
        }*/
        /*StringBuilder query = new StringBuilder();


        Enumeration<String> parameterNames = request.getParameterNames();
        while (parameterNames.hasMoreElements()) {
            System.out.println(parameterNames.nextElement());
        }*/

        //BasicQuery query = new BasicQuery();







        return contactJson;

    }



    public String stringifyJsonFromContacts(Object o){

        String contactJson = "[]";
        ObjectMapper mapper = new ObjectMapper();
        try {
            contactJson = mapper.writeValueAsString(o);
        }catch (Exception e){
            System.out.println("the exception ==>>"+e.toString());
        }
        return contactJson;
    }
}
