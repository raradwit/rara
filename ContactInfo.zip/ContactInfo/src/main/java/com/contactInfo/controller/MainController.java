package com.contactInfo.controller;

import com.contactInfo.model.Contact;
import com.contactInfo.scripts.MConnection;
import com.contactInfo.services.ContactService;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.util.JSON;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

//import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * Created by spandey on 4/13/15.
 */
@Controller
public class MainController {

    //MongoOperations mongoOperation;
    ContactService contactService;

    public void beanInit(){
        // For Annotation
        /*ApplicationContext ctx =
                new AnnotationConfigApplicationContext(MConnection.class);
        mongoOperation = (MongoOperations) ctx.getBean("mongoTemplate");*/

        ApplicationContext ctx = new GenericXmlApplicationContext("SpringConfig.xml");
        //mongoOperation = (MongoOperations)ctx.getBean("mongoTemplate");
        contactService = (ContactService)ctx.getBean("contactService");
    }

    @RequestMapping(value ={"/","/index"}, method = {RequestMethod.GET,RequestMethod.POST})
    public String index(HttpServletRequest request, ModelMap model){
        System.out.println("hello hleoo");
        this.beanInit();
        System.out.println("===========>>>>>>>>>>.."+contactService.getContactList1());
        model.addAttribute("model", contactService.getContactList1());
        //System.out.println(contact.getEmail().getClass());

        return "index";
    }


    @RequestMapping(value = "/saveContact", method = RequestMethod.POST)
    @ResponseBody
    public String saveContact(HttpServletRequest request){

        this.beanInit();
        String addedContact = contactService.saveContact(request);


        return addedContact;




        //return new ModelAndView("contact/list",modelMap);
    }

    @RequestMapping(value = "/deleteContact", method = RequestMethod.POST)
    @ResponseBody
    public String deleteContact(HttpServletRequest request){

        this.beanInit();
        String deltedContact = contactService.deleteContact(request);


        return deltedContact;




        //return new ModelAndView("contact/list",modelMap);
    }

    @RequestMapping(value = "/search", method = RequestMethod.GET)
    @ResponseBody
    public String angularTest(HttpServletRequest request,ModelMap model){
        this.beanInit();
        String searchContact = contactService.searchContact(request);


        return searchContact;
    }

}
