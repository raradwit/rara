package com.contactInfo.filters;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Created by spandey on 4/14/15.
 */
public class PreFilter implements Filter {

    private HttpServletRequest request;

    public void init(FilterConfig filterConfig){

    }

    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain) throws IOException, ServletException{
        request = (HttpServletRequest) servletRequest;
        //System.out.println("inside the fileter ....====>>>>"+request);

        chain.doFilter(this.request, servletResponse);
    }

    public void destroy(){

    };
}
