create database student;
create table student(
     id int PRIMARY KEY Auto_increment,
     name varchar(255),
     section char(10),
     Faculty char(10),
     course char(25),
     major varchar(255));

