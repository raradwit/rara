<?php
	include "database/connection.php";
	include "actions/MainAction.php";
	if(!isset($_GET["page"])){
		
		include "content.php";
	}
	else{
		$page = $_GET["page"];
		$action->{$page}($_POST);
	}	
?>
