    <form class="form-inline" id="studentForm" method="pho">
	    <fieldset>
	    <legend>Student Entry Form</legend>
	    <label>Full Name</label>
	    <input type="text" placeholder="Student Name" name="fname" id="fname">
		<div class="clear"></div>
<!--	    <span class="help-block">Example block-level help text here.</span> -->
	    <label>Section</label>
	    <input type="text" placeholder="Section" name="section" id="section">
		<div class="clear"></div>

	    <label>Faculty</label>
	    <input type="text" placeholder="Faculty" name="faculty" id="faculty">
		<div class="clear"></div>
	    <label>Course</label>
	    <input type="text" placeholder="Course" name="course" id="course">
		<div class="clear"></div>
	    <label>Major</label>
	    <input type="text" placeholder="Major" name="major" id="major">
		<div class="clear"></div>
	    <button type="submit" class="btn">Submit</button>
	    </fieldset>
    </form>

<script>
	$(function(){
		$( "#studentForm" ).submit(function( event ) {
			event.preventDefault();
			$.ajax({
				url:"index.php?page=insertNew",
				data:$(this).serialize(),
				type:"POST",
				success: function(data){
//					alert(data);
				alert("success");
				//window.location.reload();
				$("#student").html(data);
				},
				error:function(a){
					alert(a);
				}			
			});
		});
	});
</script>
