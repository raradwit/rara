<table id="studentTable" class="table table-striped table-bordered">
	<tr>
		<th>Full Name</th>
		<th>Section</th>
		<th>Course</th>
		<th>Major</th>
		<th>Faculty</th>
		<th>Action</th>
	</tr>
	<?php
		/*foreach($result as $k=>$v)
		{*/
		while ($v = mysql_fetch_array($result)){	
		?>

	<tr>
		<td class="name"><?=$v["name"]?></td>
		<td class="sectionName"><?=$v["section"]?></td>
		<td class="courseName"><?=$v["course"]?></td>
		<td class="majorName"><?=$v["major"]?></td>
		<td class="facultyName"><?=$v["Faculty"]?></td>
		<td class="action" dataVal="<?=$v['id']?>">
			<span style="display:block;" class="shown">
			<a class="btn btn-primary edit" href="#" >Edit</a> 
			| <a class="btn btn-danger delete" href="index.php?page=deleteEntry">Delete</a>
			</span>

			<span style="display:none" class="hidden">
			<a class="btn btn-primary update" href="index.php?page=editEntry" >Update</a> 
			| <a class="btn btn-danger cancel" href="#">Cancel</a>
			</span>
		</td>
	<tr>
	<?php
		}
	?>
	
</table>

<script type="text/javascript">


	$(".edit").click(function(){

		var parent = $(this).closest("tr");
		parent.find("td").each(function(i,col){
			if($(col).attr("class") == "action"){
				$(col).find("span.shown").hide();
				$(col).find("span.hidden").show();
			}else{
				var val = $(col).html();			
				$(col).html("<input type='text' id='"+$(col).attr("class")+"' value='"+val+"' />");
			}
		});

		return false;

	});

	$(".update").click(function(){
		var url = $(this).attr("href");
		var trParent = $(this).closest("tr");
		var parent = $(this).closest("td");
		var id = $(parent).attr("dataVal");
		var data = {name:$("#name").val(),course:$("#courseName").val(),section:$("#sectionName").val(),faculty:$("#facultyName").val(),major:$("#majorName").val(),id:id};
		$.ajax({
				url:url,
				data:data,
				type:"POST",
				success: function(data){
					alert("success");
					resetRow(trParent);
				},
				error:function(a){
					alert(a);
				}			
			});
		return false;
	});

	function resetRow(obj)
	{	
		obj.find("td").each(function(i,col){
			if($(col).attr("class") == "action"){
				$(col).find("span.shown").show();
				$(col).find("span.hidden").hide();
			}else{
				var val = $(col).find("input").val();			
				$(col).html(val);
			}
		});	

	}

	$(".cancel").click(function(){
		var parent = $(this).closest("tr");

		resetRow(parent);
		return false;
	});

	$(".delete").click(function(){
		var url = $(this).attr("href");
		var parent = $(this).closest("td");
		var trParent = $(this).closest("tr");
		var id = $(parent).attr("dataVal");
		$.ajax({
				url:url,
				data:{id:id},
				type:"POST",
				success: function(data){
					alert(data);
					trParent.remove();
				},
				error:function(a){
					alert(a);
				}			
			});
		return false;
	});

	



	/*$.ajax({

	});*/
</script>
