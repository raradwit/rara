<html>
	<head>
		<title></title>
		<script type="text/javascript" src="resource/js/jQuery-min-1.11.1.js"></script>

		<link rel="stylesheet" type="text/css" href="resource/css/bootstrap.css" />
		<script>
		$(function(){
			
		});	
		</script>
	</head>
	<body>
<div class="container">
		<div class="row">
			<div class="span9">
				<?php
					include "views/form.php";
				?>
			</div>
			<div class="clear"></div>

			<div class="span9">
				<div id="student">
				<?php $action->fetchAll();?>
				</div>
			</div>

		</div>
</div>
	</body>
</html>
