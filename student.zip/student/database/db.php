<?php 
	$DB_NAME=	"student";
	$DB_USER=	"root";
	$DB_PASS=	"root";
	$HOST_NAME=	"127.0.0.1";
?>
