<?php
class MainAction{

	private $conn;	
	public function __construct($connection){
		$this->conn = $connection;
	}

	public function fetchAll(){
		$dbh = $this->conn;
//		$sth = $dbh->prepare("select * from student");
//		$sth->execute();
//		$result = $sth->fetchAll();
		$result = mysql_query("select * from student");
		include "views/table.php";
	}

	public function insertNew($postArray){
		$dbh = $this->conn;
		/*$insert = $dbh->prepare("INSERT INTO student(name, section,Faculty,course,major) VALUES (? , ?, ?, ?, ?)");
		$insert->execute(array($postArray["fname"],$postArray["section"],$postArray["faculty"],$postArray["course"],$postArray["major"]));
		$this->fetchAll();*/
		$name = mysql_real_escape_string($postArray["fname"]);
		$section = mysql_real_escape_string($postArray["section"]);
		$faculty = mysql_real_escape_string($postArray["faculty"]);
		$course = mysql_real_escape_string($postArray["course"]);
		$major = mysql_real_escape_string($postArray["major"]);
		if(mysql_query("INSERT INTO student(name, section,Faculty,course,major) VALUES('$name','$section','$faculty','$course','$major')")){
			$this->fetchAll();	
		}
		else 
			echo mysql_error();
//		include "views/table.php";

		
	}

	public function editEntry($postArray){
		/*$dbh = $this->conn;
		$update = $dbh->prepare("update student set name=:name, section=:section, Faculty=:faculty, course=:course, major=:major where id=:id");
		$update->execute(array(
			':name'=>$postArray["name"],
			':section'=>$postArray["section"],
			':course'=>$postArray["course"],
			':major'=>$postArray["major"],
			':faculty'=>$postArray["faculty"],
			':id'=>$postArray["id"],
		));
		echo 1;*/
		$name = mysql_real_escape_string($postArray["name"]);
		$section = mysql_real_escape_string($postArray["section"]);
		$faculty = mysql_real_escape_string($postArray["faculty"]);
		$course = mysql_real_escape_string($postArray["course"]);
		$major = mysql_real_escape_string($postArray["major"]);
		$id = mysql_real_escape_string($postArray["id"]);
		$update = "update student set name='$name', section='$section', Faculty='$faculty', course='$course', major='$major' where id=$id";
		mysql_query($update) or die("some error on the way");
		echo 1;
	}

	public function deleteEntry($postArray){
		/*$dbh = $this->conn;	
		$delete = $dbh->prepare("delete from student where id=?");
		$delete->execute(array($postArray["id"]));*/
		$id = mysql_real_escape_string($postArray["id"]);
		$sql = "delete from student where id=$id";
		mysql_query($sql) or die("some error on the way");
		echo 1;
	}
	
}

	$action = new MainAction($connection->connect());

	//$action->fetchAll();
?>
